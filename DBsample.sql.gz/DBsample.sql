-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';

CREATE TABLE `alertas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `summary` varchar(255) NOT NULL,
  `idProduto` int(10) unsigned DEFAULT NULL,
  `idServidor` int(10) unsigned DEFAULT NULL,
  `dt` datetime NOT NULL,
  `gravidade` tinyint(4) NOT NULL,
  `ativo` tinyint(4) NOT NULL DEFAULT '1',
  `idGatilho` int(10) unsigned DEFAULT NULL,
  `tabelaOrigem` varchar(100) DEFAULT NULL,
  `idTabelaOrigem` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduto` (`idProduto`),
  KEY `idGatilho` (`idGatilho`),
  KEY `idServidor` (`idServidor`),
  CONSTRAINT `alertas_ibfk_1` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`),
  CONSTRAINT `alertas_ibfk_2` FOREIGN KEY (`idGatilho`) REFERENCES `gatilhos_logs` (`id`),
  CONSTRAINT `alertas_ibfk_3` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `alertas_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idAlerta` int(10) unsigned NOT NULL,
  `comment` text NOT NULL,
  `tipo` tinyint(4) NOT NULL COMMENT '1=comment, 2=clear',
  `dt` datetime NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAlerta` (`idAlerta`),
  CONSTRAINT `alertas_comments_ibfk_1` FOREIGN KEY (`idAlerta`) REFERENCES `alertas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `ambientes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `shortname` varchar(100) NOT NULL,
  `cor` varchar(30) NOT NULL,
  `padrao` tinyint(4) NOT NULL COMMENT '1 se o ambiente é padrão',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `componentes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `idProduto` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduto` (`idProduto`),
  CONSTRAINT `componentes_ibfk_1` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `conexoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `host` varchar(200) NOT NULL,
  `instancia` varchar(200) NOT NULL,
  `port` varchar(50) NOT NULL,
  `db` varchar(200) NOT NULL,
  `idKeyfun` int(10) unsigned NOT NULL,
  `tipoDb` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idKeyfun` (`idKeyfun`),
  CONSTRAINT `conexoes_ibfk_1` FOREIGN KEY (`idKeyfun`) REFERENCES `keyfun` (`id`),
  CONSTRAINT `conexoes_ibfk_2` FOREIGN KEY (`idKeyfun`) REFERENCES `keyfun` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `config_logfun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variable` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `consultas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `query` mediumtext NOT NULL,
  `grafico` tinyint(4) NOT NULL DEFAULT '0',
  `idConexao` int(10) unsigned NOT NULL,
  `tipoHistorico` varchar(50) NOT NULL,
  `historico_flag` tinyint(4) NOT NULL,
  `executar_minutos` smallint(6) NOT NULL,
  `alertar` tinyint(4) NOT NULL,
  `gravidadeAlerta` tinyint(4) NOT NULL DEFAULT '2',
  `tag` varchar(250) DEFAULT NULL,
  `idProduto` int(10) unsigned DEFAULT NULL,
  `email` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idConexao` (`idConexao`),
  KEY `idProduto` (`idProduto`),
  CONSTRAINT `consultas_ibfk_1` FOREIGN KEY (`idConexao`) REFERENCES `conexoes` (`id`),
  CONSTRAINT `consultas_ibfk_2` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `consultas_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idConsulta` int(10) unsigned NOT NULL,
  `dtCreated` datetime NOT NULL,
  `json_content` mediumtext NOT NULL,
  `json_md5` varchar(50) NOT NULL,
  `rows` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idConsulta` (`idConsulta`),
  CONSTRAINT `consultas_history_ibfk_1` FOREIGN KEY (`idConsulta`) REFERENCES `consultas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `dashboard_consolidados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idProduto` int(10) unsigned NOT NULL,
  `idAmbiente` int(10) unsigned NOT NULL,
  `dia` date NOT NULL,
  `errors` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduto` (`idProduto`),
  KEY `idAmbiente` (`idAmbiente`),
  CONSTRAINT `dashboard_consolidados_ibfk_1` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`),
  CONSTRAINT `dashboard_consolidados_ibfk_2` FOREIGN KEY (`idAmbiente`) REFERENCES `ambientes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `dashboard_consolidados_top_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idProduto` int(10) unsigned NOT NULL,
  `idAmbiente` int(10) unsigned NOT NULL,
  `dia` date NOT NULL,
  `json_msg` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduto` (`idProduto`),
  KEY `idAmbiente` (`idAmbiente`),
  CONSTRAINT `dashboard_consolidados_top_logs_ibfk_1` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`),
  CONSTRAINT `dashboard_consolidados_top_logs_ibfk_2` FOREIGN KEY (`idAmbiente`) REFERENCES `ambientes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `data_catalog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mensagem` mediumtext NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `dtInsert` datetime NOT NULL,
  `idServidor` int(10) unsigned DEFAULT NULL,
  `dtlogDateTime` datetime DEFAULT NULL,
  `idLogConfig` int(10) unsigned DEFAULT NULL,
  `microseconds` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idLogConfig` (`idLogConfig`),
  KEY `dtInsert` (`dtInsert`),
  KEY `tipo` (`tipo`(5)),
  KEY `dtlogDateTime` (`dtlogDateTime`),
  CONSTRAINT `data_catalog_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `data_catalog_ibfk_2` FOREIGN KEY (`idLogConfig`) REFERENCES `logs_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `data_eem` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mensagem` mediumtext NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `dtInsert` datetime NOT NULL,
  `idServidor` int(10) unsigned DEFAULT NULL,
  `dtlogDateTime` datetime DEFAULT NULL,
  `idLogConfig` int(10) unsigned DEFAULT NULL,
  `microseconds` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idLogConfig` (`idLogConfig`),
  KEY `tipo` (`tipo`(5)),
  KEY `dtlogDateTime` (`dtlogDateTime`),
  CONSTRAINT `data_eem_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `data_eem_ibfk_2` FOREIGN KEY (`idLogConfig`) REFERENCES `logs_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `data_itpam` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mensagem` mediumtext NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `dtInsert` datetime NOT NULL,
  `idServidor` int(10) unsigned DEFAULT NULL,
  `dtlogDateTime` datetime DEFAULT NULL,
  `idLogConfig` int(10) unsigned DEFAULT NULL,
  `microseconds` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idLogConfig` (`idLogConfig`),
  KEY `tipo` (`tipo`(5)),
  KEY `dtlogDateTime` (`dtlogDateTime`),
  CONSTRAINT `data_itpam_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `data_itpam_ibfk_2` FOREIGN KEY (`idLogConfig`) REFERENCES `logs_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `data_logfun` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` text NOT NULL,
  `mensagem` mediumtext NOT NULL,
  `dtInsert` datetime NOT NULL,
  `idServidor` int(10) unsigned DEFAULT NULL,
  `dtlogDateTime` datetime DEFAULT NULL,
  `idLogConfig` int(10) unsigned DEFAULT NULL,
  `microseconds` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idLogConfig` (`idLogConfig`),
  KEY `dtInsert` (`dtInsert`),
  KEY `tipo` (`tipo`(5)),
  KEY `dtlogDateTime` (`dtlogDateTime`),
  CONSTRAINT `data_logfun_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `data_logfun_ibfk_2` FOREIGN KEY (`idLogConfig`) REFERENCES `logs_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `data_sdm` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dtlog` varchar(255) NOT NULL,
  `servidor` varchar(255) NOT NULL,
  `objeto` varchar(255) NOT NULL,
  `objeto_linha` varchar(255) NOT NULL,
  `tipo` varchar(255) NOT NULL,
  `arquivo` varchar(255) NOT NULL,
  `arquivo_linha` varchar(255) NOT NULL,
  `mensagem` mediumtext NOT NULL,
  `mensagemFull` mediumtext NOT NULL,
  `dtInsert` datetime NOT NULL,
  `dtlogDateTime` datetime DEFAULT NULL,
  `idServidor` int(10) unsigned DEFAULT NULL,
  `idLogConfig` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idLogConfig` (`idLogConfig`),
  KEY `dtInsert` (`dtInsert`),
  KEY `tipo` (`tipo`(11)),
  KEY `dtlogDateTime` (`dtlogDateTime`),
  CONSTRAINT `data_sdm_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `data_sdm_ibfk_2` FOREIGN KEY (`idLogConfig`) REFERENCES `logs_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `data_soi` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mensagem` mediumtext NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `dtInsert` datetime NOT NULL,
  `idServidor` int(10) unsigned DEFAULT NULL,
  `dtlogDateTime` datetime DEFAULT NULL,
  `idLogConfig` int(10) unsigned DEFAULT NULL,
  `microseconds` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idLogConfig` (`idLogConfig`),
  KEY `dtInsert` (`dtInsert`),
  KEY `tipo` (`tipo`(5)),
  KEY `dtlogDateTime` (`dtlogDateTime`),
  CONSTRAINT `data_soi_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `data_soi_ibfk_2` FOREIGN KEY (`idLogConfig`) REFERENCES `logs_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `data_sql` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mensagem` mediumtext NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `dtInsert` datetime NOT NULL,
  `idServidor` int(10) unsigned DEFAULT NULL,
  `dtlogDateTime` datetime DEFAULT NULL,
  `idLogConfig` int(10) unsigned DEFAULT NULL,
  `microseconds` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idLogConfig` (`idLogConfig`),
  CONSTRAINT `data_sql_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `data_sql_ibfk_2` FOREIGN KEY (`idLogConfig`) REFERENCES `logs_config` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `disk_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idServidor` int(10) unsigned NOT NULL,
  `disk` varchar(10) NOT NULL,
  `disk_size` varchar(50) NOT NULL,
  `disk_free` varchar(50) NOT NULL,
  `dtCreated` datetime NOT NULL,
  `lastModFile` datetime NOT NULL COMMENT 'Ultima modificação do arquivo fonte',
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  CONSTRAINT `disk_history_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `localPath` varchar(255) NOT NULL,
  `networkPath` varchar(255) NOT NULL,
  `idServidor` int(10) unsigned NOT NULL,
  `descricao` tinytext NOT NULL,
  `lastMod` datetime NOT NULL,
  `monitored` tinyint(4) NOT NULL,
  `monitoredmd5` tinyint(4) NOT NULL,
  `monitoredsize` int(11) NOT NULL,
  `fromFolder` varchar(250) NOT NULL,
  `alertar` tinyint(4) NOT NULL,
  `apagado` tinyint(4) NOT NULL,
  `folder` tinyint(4) NOT NULL,
  `subdir` tinyint(4) NOT NULL,
  `senhacertificado` varchar(50) NOT NULL,
  `executar_minutos` smallint(6) NOT NULL DEFAULT '5',
  `filter` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  CONSTRAINT `files_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `files_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idFile` int(10) unsigned NOT NULL,
  `checksum` varchar(200) NOT NULL,
  `body` mediumtext NOT NULL,
  `size` varchar(100) NOT NULL,
  `dtCreated` datetime NOT NULL,
  `info` varchar(200) NOT NULL,
  `flag_gold` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idFile` (`idFile`),
  CONSTRAINT `files_history_ibfk_1` FOREIGN KEY (`idFile`) REFERENCES `files` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `fixes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `descricao` varchar(200) NOT NULL,
  `url` varchar(255) NOT NULL,
  `idProduto` int(10) unsigned NOT NULL,
  `importante` tinyint(4) NOT NULL,
  `dtPublicado` datetime NOT NULL,
  `versaoProduto` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduto` (`idProduto`),
  CONSTRAINT `fixes_ibfk_1` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `gatilhos_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `texto` varchar(255) NOT NULL,
  `tipo` smallint(6) NOT NULL COMMENT '0=normal, 1=sql',
  `solucionado` tinyint(4) NOT NULL,
  `ativo` tinyint(4) NOT NULL DEFAULT '1',
  `email` tinyint(4) NOT NULL,
  `emailBody` varchar(255) NOT NULL,
  `gravidade` tinyint(4) NOT NULL,
  `idWiki` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idWiki` (`idWiki`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `health` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idAmbiente` int(10) unsigned NOT NULL,
  `idProduto` int(10) unsigned NOT NULL,
  `idServidor` int(10) unsigned NOT NULL,
  `label` varchar(200) NOT NULL,
  `port` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  `lastPing` datetime NOT NULL,
  `lastPingOK` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAmbiente` (`idAmbiente`),
  KEY `idProduto` (`idProduto`),
  KEY `idServidor` (`idServidor`),
  CONSTRAINT `health_ibfk_1` FOREIGN KEY (`idAmbiente`) REFERENCES `ambientes` (`id`),
  CONSTRAINT `health_ibfk_2` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`),
  CONSTRAINT `health_ibfk_3` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `health_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idHealth` int(10) unsigned NOT NULL,
  `status` varchar(20) NOT NULL,
  `dt` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idHealth` (`idHealth`),
  CONSTRAINT `health_history_ibfk_1` FOREIGN KEY (`idHealth`) REFERENCES `health` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `keyfun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `usuario` varchar(200) NOT NULL,
  `senha` varchar(250) NOT NULL,
  `idProduto` int(10) unsigned NOT NULL,
  `idAmbiente` int(10) unsigned NOT NULL,
  `descricao` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduto` (`idProduto`),
  KEY `idAmbiente` (`idAmbiente`),
  CONSTRAINT `keyfun_ibfk_1` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`),
  CONSTRAINT `keyfun_ibfk_2` FOREIGN KEY (`idAmbiente`) REFERENCES `ambientes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `lf_audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idUsuario` int(10) unsigned NOT NULL,
  `dt` datetime NOT NULL,
  `class` varchar(200) NOT NULL,
  `idClass` varchar(100) NOT NULL,
  `query` mediumtext NOT NULL,
  `tipo` varchar(5) NOT NULL COMMENT 'add ou edt',
  PRIMARY KEY (`id`),
  KEY `idUsuario` (`idUsuario`),
  CONSTRAINT `lf_audit_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `lf_usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `lf_usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(255) NOT NULL,
  `displayName` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `tipoAuth` varchar(50) NOT NULL DEFAULT 'ldap' COMMENT 'ldap ou bd',
  `tipo` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=user, 2=grupo',
  `ativo` tinyint(4) NOT NULL DEFAULT '1',
  `lastLogin` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `lf_usuarios_grupos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idUsuario` int(10) unsigned NOT NULL,
  `idGrupo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idUsuario` (`idUsuario`),
  KEY `idGrupo` (`idGrupo`),
  CONSTRAINT `lf_usuarios_grupos_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `lf_usuarios` (`id`),
  CONSTRAINT `lf_usuarios_grupos_ibfk_2` FOREIGN KEY (`idGrupo`) REFERENCES `lf_usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `lf_usuarios_permissoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idUsuario` int(10) unsigned NOT NULL,
  `permissao` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idUsuario` (`idUsuario`),
  CONSTRAINT `lf_usuarios_permissoes_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `lf_usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `idCategoria` int(10) unsigned NOT NULL,
  `ordem` int(10) unsigned NOT NULL DEFAULT '0',
  `cor` varchar(50) NOT NULL,
  `ssl` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idCategoria` (`idCategoria`),
  CONSTRAINT `links_ibfk_1` FOREIGN KEY (`idCategoria`) REFERENCES `links_categorias` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `links_categorias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `bgcolor` varchar(200) NOT NULL,
  `idCatPai` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `logs_agents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logLevel` varchar(6) NOT NULL,
  `idServidor` int(10) unsigned NOT NULL,
  `active` tinyint(3) NOT NULL DEFAULT '1',
  `version` varchar(20) NOT NULL,
  `lastContact` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastMD5AgentFile` varchar(32) NOT NULL,
  `needUpdate` tinyint(1) NOT NULL DEFAULT '0',
  `lastUpdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  CONSTRAINT `logs_agents_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `logs_agents_update_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filePath` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `logs_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idFileTpl` int(10) unsigned DEFAULT NULL,
  `idProdutos` int(10) unsigned NOT NULL,
  `idTemplate` int(10) unsigned DEFAULT NULL,
  `idAmbiente_OLD` int(10) unsigned NOT NULL,
  `proc` varchar(200) NOT NULL COMMENT 'PROCEDURE_ que vai dar CALL',
  `idConfigTbl` int(10) unsigned DEFAULT NULL,
  `idAgente` varchar(200) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idProdutos` (`idProdutos`),
  KEY `idAmbiente` (`idAmbiente_OLD`),
  KEY `idFile` (`idFileTpl`),
  KEY `idConfigTbl` (`idConfigTbl`),
  KEY `idTemplate` (`idTemplate`),
  CONSTRAINT `logs_config_ibfk_1` FOREIGN KEY (`idProdutos`) REFERENCES `produtos` (`id`),
  CONSTRAINT `logs_config_ibfk_4` FOREIGN KEY (`idFileTpl`) REFERENCES `logs_files_tpl` (`id`),
  CONSTRAINT `logs_config_ibfk_5` FOREIGN KEY (`idConfigTbl`) REFERENCES `logs_config_tbl` (`id`),
  CONSTRAINT `logs_config_ibfk_6` FOREIGN KEY (`idTemplate`) REFERENCES `logs_templates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `logs_config_tbl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `colError` varchar(100) NOT NULL,
  `txtError` varchar(100) NOT NULL,
  `txtInfo` varchar(100) NOT NULL DEFAULT 'INFO',
  `tipos` varchar(255) NOT NULL,
  `extraListColumns` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `logs_files_tpl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `localPath` varchar(255) NOT NULL,
  `descricao` tinytext NOT NULL,
  `idProduto` int(10) unsigned DEFAULT NULL,
  `newLinePattern` varchar(64) DEFAULT NULL,
  `typeConversion` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idProduto` (`idProduto`),
  CONSTRAINT `logs_files_tpl_ibfk_1` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `logs_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `produtos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `nomefull` varchar(100) NOT NULL,
  `dashboardErrorThreshold` smallint(6) NOT NULL DEFAULT '500' COMMENT 'Número de erros limite para o dashboard mudar de cor',
  `dashboardTotalThreshold` int(11) NOT NULL DEFAULT '50000' COMMENT 'Total de logs limite para o dashboard mudar de cor',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `rel_ambientes_gatilhos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idAmbiente` int(10) unsigned NOT NULL,
  `idGatilho` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAmbiente` (`idAmbiente`),
  KEY `idGatilho` (`idGatilho`),
  CONSTRAINT `rel_ambientes_gatilhos_ibfk_1` FOREIGN KEY (`idAmbiente`) REFERENCES `ambientes` (`id`),
  CONSTRAINT `rel_ambientes_gatilhos_ibfk_2` FOREIGN KEY (`idGatilho`) REFERENCES `gatilhos_logs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `rel_componentes_keyfun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idComponente` int(10) unsigned NOT NULL,
  `idKeyfun` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idComponente` (`idComponente`),
  KEY `idKeyfun` (`idKeyfun`),
  CONSTRAINT `rel_componentes_keyfun_ibfk_1` FOREIGN KEY (`idComponente`) REFERENCES `componentes` (`id`),
  CONSTRAINT `rel_componentes_keyfun_ibfk_2` FOREIGN KEY (`idKeyfun`) REFERENCES `keyfun` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `rel_logs_servidores_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idServidor` int(10) unsigned NOT NULL,
  `idTemplate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idTemplate` (`idTemplate`),
  CONSTRAINT `rel_logs_servidores_templates_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `rel_logs_servidores_templates_ibfk_2` FOREIGN KEY (`idTemplate`) REFERENCES `logs_templates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `rel_produtos_gatilhos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idProduto` int(10) unsigned NOT NULL,
  `idGatilho` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idProduto` (`idProduto`),
  KEY `idGatilho` (`idGatilho`),
  CONSTRAINT `rel_produtos_gatilhos_ibfk_1` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`),
  CONSTRAINT `rel_produtos_gatilhos_ibfk_2` FOREIGN KEY (`idGatilho`) REFERENCES `gatilhos_logs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `rel_servidores_produtos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idServidor` int(10) unsigned NOT NULL,
  `idProduto` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idServidor` (`idServidor`),
  KEY `idProduto` (`idProduto`),
  CONSTRAINT `rel_servidores_produtos_ibfk_1` FOREIGN KEY (`idServidor`) REFERENCES `servidores` (`id`),
  CONSTRAINT `rel_servidores_produtos_ibfk_2` FOREIGN KEY (`idProduto`) REFERENCES `produtos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `servidores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `idAmbiente` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idAmbiente` (`idAmbiente`),
  CONSTRAINT `servidores_ibfk_1` FOREIGN KEY (`idAmbiente`) REFERENCES `ambientes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `wiki` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `body` longtext NOT NULL,
  `body_strip` longtext NOT NULL,
  `dtCreated` datetime NOT NULL,
  `dtLastmod` datetime NOT NULL,
  `idWikiTipo` int(10) unsigned NOT NULL DEFAULT '1',
  `idWikiStatus` int(10) unsigned NOT NULL DEFAULT '1',
  `search` varchar(200) NOT NULL,
  `favorito` tinyint(3) unsigned NOT NULL,
  `idProduto` int(10) unsigned DEFAULT NULL,
  `idExterno` varchar(100) NOT NULL,
  `dtCreatedExterno` datetime NOT NULL,
  `dtEndExterno` datetime NOT NULL,
  `urlExterna` varchar(250) NOT NULL,
  `idExternoSD` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idWikiTipo` (`idWikiTipo`),
  KEY `idWikiStatus` (`idWikiStatus`),
  KEY `idProduto` (`idProduto`),
  CONSTRAINT `wiki_ibfk_2` FOREIGN KEY (`idWikiTipo`) REFERENCES `wiki_tipos` (`id`),
  CONSTRAINT `wiki_ibfk_3` FOREIGN KEY (`idWikiStatus`) REFERENCES `wiki_status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `wiki_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `cor` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `wiki_tipos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) NOT NULL,
  `cor` varchar(50) NOT NULL,
  `icone` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2018-07-04 12:25:08
